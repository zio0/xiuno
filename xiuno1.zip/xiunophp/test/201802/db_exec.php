<?php exit;?>	2018-02-05 22:27:05	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_cache.php	0	REPLACE INTO bbs_cache (`k`,`v`,`expiry`) VALUES ('pre_test','[     \"123\" ]','0')
<?php exit;?>	2018-02-05 22:27:05	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_cache.php	0	DELETE FROM bbs_cache  WHERE `k`='pre_test' 
<?php exit;?>	2018-02-05 22:27:06	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_cache.php	0	REPLACE INTO bbs_cache (`k`,`v`,`expiry`) VALUES ('pre_test','[     \"123\" ]','0')
<?php exit;?>	2018-02-05 22:27:06	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_cache.php	0	DELETE FROM bbs_cache  WHERE `k`='pre_test' 
