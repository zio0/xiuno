<?php exit;?>	2018-02-05 22:26:50	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM `user` WHERE uid='1' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:50	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO user SET uid=1000, username='test1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:50	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:50	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:50	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='0' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:51	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM `user` WHERE uid='1' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:51	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO user SET uid=1000, username='test1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:51	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:51	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:51	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='0' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM `user` WHERE uid='1' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO user SET uid=1000, username='test1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='0' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM `user` WHERE uid='1' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO user SET uid=1000, username='test1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='0' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM `user` WHERE uid='1' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO user SET uid=1000, username='test1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:52	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='0' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:58	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM `user` WHERE uid='1' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:58	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO user SET uid=1000, username='test1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:58	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:58	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:26:58	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='0' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:11	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM `user` WHERE uid='1' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:11	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO user SET uid=1000, username='test1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:11	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:11	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:11	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='0' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:11	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM `user` WHERE uid='1' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:11	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO user SET uid=1000, username='test1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:11	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:11	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:11	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='0' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:12	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM `user` WHERE uid='1' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:12	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO user SET uid=1000, username='test1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:12	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:12	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:12	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='0' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:51	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM `user` WHERE uid='1' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:51	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO user SET uid=1000, username='test1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:51	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:51	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:51	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='0' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:54	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM `user` WHERE uid='1' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:54	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO user SET uid=1000, username='test1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:54	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:54	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:27:54	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='0' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:28:13	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO user SET uid=1000, username='test1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:28:13	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:28:13	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:28:13	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:SELECT * FROM user WHERE uid='0' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:28:30	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM user WHERE bbs_uid='1000' errno: 1146, errstr: Table 'xiuno8.user' doesn't exist
<?php exit;?>	2018-02-05 22:28:48	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO bbs_user SET uid=1000, username='test1000' errno: 1062, errstr: Duplicate entry '1000' for key 'PRIMARY'
<?php exit;?>	2018-02-05 22:28:48	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM bbs_ WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.bbs_' doesn't exist
<?php exit;?>	2018-02-05 22:29:38	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO bbs_user SET uid=1000, username='test1000' errno: 1062, errstr: Duplicate entry '1000' for key 'PRIMARY'
<?php exit;?>	2018-02-05 22:29:38	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:DELETE FROM bbs_ WHERE uid='1000' errno: 1146, errstr: Table 'xiuno8.bbs_' doesn't exist
<?php exit;?>	2018-02-05 22:29:46	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO bbs_user SET uid=1000, username='test1000' errno: 1062, errstr: Duplicate entry '1000' for key 'PRIMARY'
<?php exit;?>	2018-02-05 22:31:23	127.0.0.1	/bbs.xiuno.com/xiunophp/test/test_mysql.php	0	SQL:INSERT INTO bbs_user SET uid=1000, username='test1000' errno: 1062, errstr: Duplicate entry '1000' for key 'PRIMARY'
